def play(state):
    if state.Player.prev_y - state.Submarine.prev_x  <= -0.37:
        if state.Shark.prev_x - state.Submarine.x  <= 0.12:
            if state.Diver.prev_y - state.Shark.x  <= 0.92:
                if state.Player.prev_y - state.Submarine.prev_x  <= -0.97:
                    return "UPRIGHTFIRE"
                else:
                    return "UPRIGHTFIRE"
            else:
                return "DOWNRIGHTFIRE"
        else:
            if state.Shark.x - state.Shark.y  <= 1.01:
                if state.Shark.x - state.Shark.y  <= -4.61:
                    return "UPRIGHTFIRE"
                else:
                    return "UPRIGHTFIRE"
            else:
                if state.Player.prev_y - state.Submarine.prev_x  <= -0.91:
                    return "DOWNRIGHTFIRE"
                else:
                    if state.Player.prev_y - state.Shark.prev_x  <= -0.46:
                        return "DOWNFIRE"
                    else:
                        return "DOWNRIGHTFIRE"
    else:
        if state.Diver.x - state.Shark.prev_x  <= 0.32:
            if state.Shark.prev_x - state.Submarine.x  <= 0.19:
                if state.Player.prev_y - state.Submarine.prev_x  <= 1.07:
                    if state.Diver.prev_y - state.EnemyMissile.x  <= 0.19:
                        if state.Diver.prev_y - state.EnemyMissile.prev_x  <= -3.56:
                            return "UPRIGHTFIRE"
                        else:
                            return "DOWNFIRE"
                    else:
                        if state.Shark.prev_x - state.Submarine.prev_x  <= 0.07:
                            return "UPFIRE"
                        else:
                            return "UPFIRE"
                else:
                    return "UPLEFTFIRE"
            else:
                if state.Player.prev_x - state.EnemyMissile.prev_x  <= -0.21:
                    if state.Shark.x - state.Shark.y  <= 0.99:
                        return "DOWNFIRE"
                    else:
                        return "DOWNFIRE"
                else:
                    if state.Player.prev_y - state.Submarine.prev_x  <= 1.17:
                        if state.Player.prev_y - state.Diver.x  <= 1.47:
                            if state.Shark.prev_x - state.PlayerMissile.x  <= 1.93:
                                if state.Diver.x - state.Diver.x  <= -0.48:
                                    return "DOWNFIRE"
                                else:
                                    return "UPFIRE"
                            else:
                                return "UPRIGHTFIRE"
                        else:
                            return "DOWNLEFTFIRE"
                    else:
                        if state.Player.prev_y - state.Shark.x  <= -0.42:
                            return "DOWNLEFTFIRE"
                        else:
                            return "UPLEFTFIRE"
        else:
            if state.Diver.prev_x - state.Shark.prev_y  <= 0.33:
                if state.Diver.prev_x - state.Submarine.prev_x  <= -2.33:
                    if state.Diver.prev_x - state.PlayerMissile.prev_x  <= -4.63:
                        return "UPRIGHTFIRE"
                    else:
                        return "UPFIRE"
                else:
                    if state.Shark.y - state.Shark.y  <= -1.41:
                        return "DOWNLEFT"
                    else:
                        return "DOWNFIRE"
            else:
                if state.Diver.x - state.Shark.x  <= 0.92:
                    if state.Player.prev_y - state.Submarine.x  <= 0.63:
                        return "UPFIRE"
                    else:
                        if state.Diver.x - state.Submarine.x  <= -0.73:
                            return "UPLEFTFIRE"
                        else:
                            if state.Diver.prev_x - state.Shark.x  <= 0.19:
                                if state.Diver.prev_y - state.Shark.x  <= -4.89:
                                    return "UPRIGHTFIRE"
                                else:
                                    return "UPLEFTFIRE"
                            else:
                                return "UPLEFT"
                else:
                    if state.Shark.prev_x - state.Submarine.prev_y  <= 0.19:
                        return "DOWN"
                    else:
                        return "LEFTFIRE"
