def play(state):
    if state.Enemy.x - state.Player.prev_x  <= -2.07:
        if state.BallShadow.prev_x - state.Enemy.x  <= -1.35:
            return "DOWNRIGHT"
        else:
            return "UPRIGHT"
    else:
        if state.Player.prev_x - state.Player.x  <= 0.07:
            if state.BallShadow.prev_y - state.Player.x  <= -1.36:
                if state.Enemy.prev_x - state.Player.y  <= -0.00:
                    return "DOWNLEFT"
                else:
                    return "DOWNLEFT"
            else:
                if state.Ball.prev_x - state.Player.y  <= -2.11:
                    return "UPRIGHT"
                else:
                    if state.Enemy.x - state.Player.prev_x  <= -0.31:
                        if state.Ball.x - state.Player.prev_y  <= 0.94:
                            return "UPRIGHT"
                        else:
                            if state.Ball.y - state.Enemy.prev_x  <= 0.30:
                                return "UP"
                            else:
                                return "UPLEFTFIRE"
                    else:
                        if state.Ball.prev_y - state.Enemy.x  <= 0.36:
                            return "UPLEFTFIRE"
                        else:
                            if state.BallShadow.prev_y - state.Ball.prev_y  <= -0.45:
                                return "DOWNLEFT"
                            else:
                                return "DOWNLEFT"
        else:
            if state.BallShadow.prev_y <= 0.75:
                if state.Ball.y - state.Player.prev_y  <= -0.50:
                    if state.Ball.x - state.Player.prev_y  <= 0.66:
                        return "UPRIGHT"
                    else:
                        return "UPRIGHT"
                else:
                    return "UPRIGHT"
            else:
                if state.Ball.prev_x - state.Enemy.prev_y  <= -0.69:
                    return "DOWNRIGHT"
                else:
                    return "RIGHTFIRE"
