def play(state):
    if state.Player.prev_x - state.Enemy.x  <= -2.07:
        if state.Enemy.x - state.BallShadow.prev_x  <= -1.35:
            return "DOWNRIGHT"
        else:
            return "UPRIGHT"
    else:
        if state.Player.x - state.Player.prev_x  <= 0.07:
            if state.Player.x - state.BallShadow.prev_y  <= -1.36:
                if state.Player.y - state.Enemy.prev_x  <= -0.00:
                    return "DOWNLEFT"
                else:
                    return "DOWNLEFT"
            else:
                if state.Player.y - state.Ball.prev_x  <= -2.11:
                    return "UPRIGHT"
                else:
                    if state.Player.prev_x - state.Enemy.x  <= -0.31:
                        if state.Player.prev_y - state.Ball.x  <= 0.94:
                            return "UPRIGHT"
                        else:
                            if state.Enemy.prev_x - state.Ball.y  <= 0.30:
                                return "UP"
                            else:
                                return "UPLEFTFIRE"
                    else:
                        if state.Enemy.x - state.Ball.prev_y  <= 0.36:
                            return "UPLEFTFIRE"
                        else:
                            if state.Ball.prev_y - state.BallShadow.prev_y  <= -0.45:
                                return "DOWNLEFT"
                            else:
                                return "DOWNLEFT"
        else:
            if state.BallShadow.prev_y <= 0.75:
                if state.Player.prev_y - state.Ball.y  <= -0.50:
                    if state.Player.prev_y - state.Ball.x  <= 0.66:
                        return "UPRIGHT"
                    else:
                        return "UPRIGHT"
                else:
                    return "UPRIGHT"
            else:
                if state.Enemy.prev_y - state.Ball.prev_x  <= -0.69:
                    return "DOWNRIGHT"
                else:
                    return "RIGHTFIRE"
