def play(state):
    if state.Alien.prev_x - state.Alien.y  <= 0.94:
        if state.Bullet.prev_y - state.Alien.y  <= -0.29:
            if state.Alien.x - state.Alien.y  <= 0.83:
                return "NOOP"
            else:
                return "RIGHT"
        else:
            if state.Alien.x - state.Alien.prev_y  <= 0.07:
                if state.Alien.x - state.Alien.prev_y  <= -0.58:
                    if state.Bullet.prev_y - state.Alien.prev_x  <= 0.91:
                        return "LEFTFIRE"
                    else:
                        return "LEFTFIRE"
                else:
                    if state.Alien.prev_x - state.Alien.prev_x  <= 0.52:
                        return "RIGHTFIRE"
                    else:
                        return "FIRE"
            else:
                if state.Alien.y - state.Alien.x  <= 1.23:
                    if state.Bullet.prev_y - state.Alien.prev_y  <= 1.12:
                        return "RIGHTFIRE"
                    else:
                        return "LEFTFIRE"
                else:
                    if state.Alien.x - state.Alien.x  <= 0.47:
                        return "RIGHTFIRE"
                    else:
                        return "RIGHTFIRE"
    else:
        if state.Alien.y - state.Alien.y  <= 1.27:
            if state.Alien.prev_y - state.Alien.prev_x  <= 0.16:
                if state.Bullet.prev_y - state.Player.prev_x  <= 1.41:
                    return "LEFTFIRE"
                else:
                    return "RIGHTFIRE"
            else:
                if state.Alien.prev_y - state.Alien.prev_x  <= 0.54:
                    return "LEFTFIRE"
                else:
                    return "LEFTFIRE"
        else:
            if state.Bullet.y - state.Player.x  <= -1.28:
                return "RIGHTFIRE"
            else:
                return "LEFTFIRE"
