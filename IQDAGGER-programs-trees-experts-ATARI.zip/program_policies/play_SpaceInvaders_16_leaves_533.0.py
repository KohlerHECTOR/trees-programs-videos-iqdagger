def play(state):
    if state.Alien.y - state.Alien.prev_x  <= 0.94:
        if state.Alien.y - state.Bullet.prev_y  <= -0.29:
            if state.Alien.y - state.Alien.x  <= 0.83:
                return "NOOP"
            else:
                return "RIGHT"
        else:
            if state.Alien.prev_y - state.Alien.x  <= 0.07:
                if state.Alien.prev_y - state.Alien.x  <= -0.58:
                    if state.Alien.prev_x - state.Bullet.prev_y  <= 0.91:
                        return "LEFTFIRE"
                    else:
                        return "LEFTFIRE"
                else:
                    if state.Alien.prev_x - state.Alien.prev_x  <= 0.52:
                        return "RIGHTFIRE"
                    else:
                        return "FIRE"
            else:
                if state.Alien.x - state.Alien.y  <= 1.23:
                    if state.Alien.prev_y - state.Bullet.prev_y  <= 1.12:
                        return "RIGHTFIRE"
                    else:
                        return "LEFTFIRE"
                else:
                    if state.Alien.x - state.Alien.x  <= 0.47:
                        return "RIGHTFIRE"
                    else:
                        return "RIGHTFIRE"
    else:
        if state.Alien.y - state.Alien.y  <= 1.27:
            if state.Alien.prev_x - state.Alien.prev_y  <= 0.16:
                if state.Player.prev_x - state.Bullet.prev_y  <= 1.41:
                    return "LEFTFIRE"
                else:
                    return "RIGHTFIRE"
            else:
                if state.Alien.prev_x - state.Alien.prev_y  <= 0.54:
                    return "LEFTFIRE"
                else:
                    return "LEFTFIRE"
        else:
            if state.Player.x - state.Bullet.y  <= -1.28:
                return "RIGHTFIRE"
            else:
                return "LEFTFIRE"
