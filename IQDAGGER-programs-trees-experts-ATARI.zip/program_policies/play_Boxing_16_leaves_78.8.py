def play(state):
    if state.Enemy.x - state.Enemy.y  <= -0.06:
        if state.Enemy.y - state.Enemy.prev_y  <= -0.18:
            if state.Player.prev_x - state.Enemy.prev_y  <= 0.03:
                return "RIGHT"
            else:
                return "DOWNRIGHTFIRE"
        else:
            if state.Enemy.x <= 0.55:
                if state.Player.x <= -0.40:
                    return "RIGHT"
                else:
                    if state.Enemy.x - state.Enemy.prev_y  <= -0.63:
                        return "DOWNRIGHT"
                    else:
                        if state.Enemy.y - state.Enemy.prev_y  <= 0.00:
                            if state.Player.prev_x <= 0.39:
                                return "UPRIGHTFIRE"
                            else:
                                return "DOWNRIGHTFIRE"
                        else:
                            return "UPRIGHTFIRE"
            else:
                return "DOWNLEFT"
    else:
        if state.Player.prev_x <= -0.20:
            if state.Player.y - state.Enemy.prev_x  <= 0.81:
                if state.Enemy.x <= 0.45:
                    if state.Player.y - state.Enemy.prev_x  <= 0.10:
                        return "UPRIGHT"
                    else:
                        return "UPRIGHT"
                else:
                    return "DOWNLEFT"
            else:
                return "UPLEFT"
        else:
            if state.Player.x - state.Enemy.x  <= 0.58:
                return "UPLEFT"
            else:
                if state.Enemy.y - state.Enemy.prev_y  <= -0.34:
                    return "DOWNRIGHTFIRE"
                else:
                    if state.Enemy.x - state.Enemy.prev_y  <= 0.84:
                        return "DOWNLEFT"
                    else:
                        return "DOWNLEFT"
