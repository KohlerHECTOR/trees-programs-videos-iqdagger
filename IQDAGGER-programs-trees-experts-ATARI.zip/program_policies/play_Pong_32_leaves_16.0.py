def play(state):
    if state.Ball.prev_x <= 1.24:
        if state.Ball.prev_x - state.Enemy.prev_y  <= -0.41:
            if state.Player.prev_y - state.Ball.y  <= 0.09:
                if state.Ball.x - state.Ball.prev_y  <= -0.91:
                    if state.Ball.x <= 0.73:
                        if state.Player.y - state.Ball.x  <= -1.20:
                            return "LEFT"
                        else:
                            return "RIGHT"
                    else:
                        return "NOOP"
                else:
                    if state.Ball.x <= -0.05:
                        return "NOOP"
                    else:
                        if state.Player.y - state.Player.prev_y  <= -0.19:
                            return "NOOP"
                        else:
                            if state.Ball.x - state.Ball.prev_x  <= -0.38:
                                return "NOOP"
                            else:
                                if state.Player.prev_y - state.Ball.y  <= -0.09:
                                    return "RIGHT"
                                else:
                                    return "RIGHT"
            else:
                return "RIGHT"
        else:
            if state.Ball.x - state.Enemy.prev_y  <= -1.46:
                if state.Player.y - state.Enemy.prev_y  <= -0.92:
                    return "LEFT"
                else:
                    return "RIGHT"
            else:
                if state.Player.y - state.Ball.prev_x  <= -0.63:
                    if state.Ball.prev_x <= -0.05:
                        return "LEFT"
                    else:
                        if state.Player.y - state.Ball.prev_x  <= -0.80:
                            return "LEFT"
                        else:
                            if state.Ball.prev_x <= 0.80:
                                return "LEFT"
                            else:
                                return "NOOP"
                else:
                    if state.Ball.x <= -0.07:
                        if state.Ball.prev_y <= -0.15:
                            if state.Ball.prev_y <= -1.96:
                                return "LEFT"
                            else:
                                return "LEFT"
                        else:
                            return "NOOP"
                    else:
                        if state.Ball.y <= 1.24:
                            if state.Player.y - state.Ball.prev_x  <= -0.48:
                                if state.Ball.prev_x <= 0.68:
                                    return "NOOP"
                                else:
                                    return "NOOP"
                            else:
                                if state.Ball.x <= 0.54:
                                    if state.Player.y <= -0.82:
                                        return "NOOP"
                                    else:
                                        if state.Enemy.y - state.Enemy.prev_y  <= -0.09:
                                            return "RIGHT"
                                        else:
                                            return "RIGHT"
                                else:
                                    if state.Player.y - state.Enemy.y  <= -0.21:
                                        return "NOOP"
                                    else:
                                        return "RIGHT"
                        else:
                            if state.Ball.y <= 1.54:
                                return "NOOP"
                            else:
                                return "LEFT"
    else:
        if state.Player.y - state.Ball.prev_x  <= -0.54:
            if state.Player.y - state.Ball.prev_x  <= -0.88:
                return "LEFT"
            else:
                if state.Ball.y <= -1.40:
                    return "RIGHT"
                else:
                    return "NOOP"
        else:
            if state.Enemy.y - state.Enemy.prev_y  <= 0.93:
                return "RIGHT"
            else:
                return "LEFT"
