def play(state):
    if state.Chicken.y <= 1.22:
        if state.Car.x - state.Car.prev_x  <= 1.58:
            if state.Chicken.prev_y - state.Chicken.y  <= -0.00:
                return "UP"
            else:
                if state.Car.x - state.Chicken.y  <= 0.37:
                    return "UP"
                else:
                    if state.Car.prev_x - state.Car.x  <= -0.92:
                        if state.Car.x - state.Car.x  <= 1.21:
                            if state.Car.x - state.Car.x  <= -0.16:
                                return "UP"
                            else:
                                return "NOOP"
                        else:
                            return "UP"
                    else:
                        if state.Car.prev_x - state.Car.x  <= -0.01:
                            if state.Car.prev_x - state.Car.x  <= 1.32:
                                return "UP"
                            else:
                                if state.Car.prev_x - state.Car.x  <= 0.49:
                                    return "UP"
                                else:
                                    return "UP"
                        else:
                            return "DOWN"
        else:
            if state.Car.prev_x - state.Chicken.prev_y  <= 0.84:
                if state.Car.x - state.Chicken.y  <= -1.11:
                    return "NOOP"
                else:
                    if state.Car.x - state.Car.x  <= -0.78:
                        if state.Car.prev_x - state.Chicken.y  <= 0.34:
                            if state.Car.x - state.Chicken.y  <= -1.70:
                                return "NOOP"
                            else:
                                return "UP"
                        else:
                            return "NOOP"
                    else:
                        return "UP"
            else:
                if state.Car.x - state.Car.x  <= -0.04:
                    if state.Car.x - state.Car.x  <= 0.66:
                        if state.Car.x - state.Car.x  <= 2.17:
                            return "UP"
                        else:
                            return "DOWN"
                    else:
                        return "UP"
                else:
                    return "UP"
    else:
        if state.Car.x - state.Car.prev_x  <= 0.63:
            if state.Car.prev_x - state.Chicken.prev_y  <= 1.23:
                if state.Car.x - state.Car.prev_x  <= 1.04:
                    if state.Car.x - state.Car.x  <= -2.60:
                        return "UP"
                    else:
                        if state.Car.prev_x - state.Car.prev_x  <= -0.91:
                            return "NOOP"
                        else:
                            if state.Car.x - state.Chicken.prev_y  <= 0.16:
                                return "UP"
                            else:
                                return "DOWN"
                else:
                    if state.Car.x - state.Car.prev_x  <= 0.96:
                        if state.Car.prev_x - state.Chicken.prev_y  <= -1.33:
                            return "NOOP"
                        else:
                            return "UP"
                    else:
                        return "UP"
            else:
                if state.Car.prev_x - state.Chicken.y  <= 1.03:
                    if state.Car.x - state.Car.x  <= 1.00:
                        return "UP"
                    else:
                        if state.Car.x - state.Car.prev_x  <= 1.81:
                            return "UP"
                        else:
                            return "DOWN"
                else:
                    if state.Car.x - state.Car.x  <= -0.31:
                        if state.Car.x - state.Chicken.y  <= 1.85:
                            return "NOOP"
                        else:
                            return "NOOP"
                    else:
                        return "UP"
        else:
            return "UP"
