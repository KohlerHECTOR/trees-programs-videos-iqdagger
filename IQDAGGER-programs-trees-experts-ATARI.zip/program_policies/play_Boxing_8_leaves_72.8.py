def play(state):
    if state.Player.prev_x <= 0.19:
        if state.Player.y - state.Enemy.prev_x  <= -0.09:
            if state.Enemy.x - state.Enemy.prev_y  <= -0.74:
                return "DOWNRIGHT"
            else:
                return "UPRIGHTFIRE"
        else:
            if state.Player.y - state.Enemy.prev_x  <= 0.75:
                return "UPRIGHT"
            else:
                return "UPLEFT"
    else:
        if state.Enemy.x - state.Enemy.y  <= -0.00:
            if state.Enemy.y - state.Enemy.prev_y  <= -0.09:
                return "DOWNRIGHTFIRE"
            else:
                if state.Enemy.y - state.Enemy.prev_x  <= 1.37:
                    return "DOWNRIGHT"
                else:
                    return "DOWNLEFT"
        else:
            return "DOWNLEFT"
