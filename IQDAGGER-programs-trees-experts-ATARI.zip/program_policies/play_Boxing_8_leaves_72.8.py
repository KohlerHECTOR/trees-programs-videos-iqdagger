def play(state):
    if state.Player.prev_x <= 0.19:
        if state.Enemy.prev_x - state.Player.y  <= -0.09:
            if state.Enemy.prev_y - state.Enemy.x  <= -0.74:
                return "DOWNRIGHT"
            else:
                return "UPRIGHTFIRE"
        else:
            if state.Enemy.prev_x - state.Player.y  <= 0.75:
                return "UPRIGHT"
            else:
                return "UPLEFT"
    else:
        if state.Enemy.y - state.Enemy.x  <= -0.00:
            if state.Enemy.prev_y - state.Enemy.y  <= -0.09:
                return "DOWNRIGHTFIRE"
            else:
                if state.Enemy.prev_x - state.Enemy.y  <= 1.37:
                    return "DOWNRIGHT"
                else:
                    return "DOWNLEFT"
        else:
            return "DOWNLEFT"
