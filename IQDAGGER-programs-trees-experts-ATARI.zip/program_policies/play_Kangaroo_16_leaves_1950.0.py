def play(state):
    if state.Monkey.x - state.Child.prev_x  <= 2.44:
        if state.Monkey.x - state.Player.x  <= 3.39:
            if state.FallingCoconut.x - state.Monkey.prev_x  <= 1.74:
                if state.FallingCoconut.prev_y <= 0.80:
                    if state.Monkey.prev_y - state.Player.prev_y  <= 1.49:
                        if state.ThrownCoconut.prev_x - state.Monkey.prev_y  <= 1.03:
                            return "DOWNLEFT"
                        else:
                            return "UPLEFTFIRE"
                    else:
                        return "LEFT"
                else:
                    if state.Monkey.y - state.Player.y  <= -1.28:
                        if state.Monkey.prev_x - state.Monkey.prev_y  <= -1.65:
                            return "RIGHT"
                        else:
                            return "RIGHT"
                    else:
                        if state.ThrownCoconut.prev_x - state.Player.y  <= 0.57:
                            if state.Monkey.x - state.Player.prev_x  <= -0.66:
                                if state.Life.x - state.Monkey.y  <= -0.99:
                                    return "DOWNLEFTFIRE"
                                else:
                                    return "DOWN"
                            else:
                                if state.Monkey.y - state.Player.prev_x  <= 0.76:
                                    return "LEFT"
                                else:
                                    return "DOWNRIGHTFIRE"
                        else:
                            return "LEFT"
            else:
                if state.Monkey.y - state.Player.x  <= 0.39:
                    return "UPRIGHT"
                else:
                    return "UPRIGHT"
        else:
            if state.Monkey.prev_y - state.Player.x  <= 2.31:
                return "DOWN"
            else:
                if state.ThrownCoconut.y - state.FallingCoconut.x  <= -0.30:
                    return "DOWN"
                else:
                    return "DOWNLEFTFIRE"
    else:
        return "LEFT"
