def play(state):
    if state.Child.prev_x - state.Monkey.x  <= 2.44:
        if state.Player.x - state.Monkey.x  <= 3.39:
            if state.Monkey.prev_x - state.FallingCoconut.x  <= 1.74:
                if state.FallingCoconut.prev_y <= 0.80:
                    if state.Player.prev_y - state.Monkey.prev_y  <= 1.49:
                        if state.Monkey.prev_y - state.ThrownCoconut.prev_x  <= 1.03:
                            return "DOWNLEFT"
                        else:
                            return "UPLEFTFIRE"
                    else:
                        return "LEFT"
                else:
                    if state.Player.y - state.Monkey.y  <= -1.28:
                        if state.Monkey.prev_y - state.Monkey.prev_x  <= -1.65:
                            return "RIGHT"
                        else:
                            return "RIGHT"
                    else:
                        if state.Player.y - state.ThrownCoconut.prev_x  <= 0.57:
                            if state.Player.prev_x - state.Monkey.x  <= -0.66:
                                if state.Monkey.y - state.Life.x  <= -0.99:
                                    return "DOWNLEFTFIRE"
                                else:
                                    return "DOWN"
                            else:
                                if state.Player.prev_x - state.Monkey.y  <= 0.76:
                                    return "LEFT"
                                else:
                                    return "DOWNRIGHTFIRE"
                        else:
                            return "LEFT"
            else:
                if state.Player.x - state.Monkey.y  <= 0.39:
                    return "UPRIGHT"
                else:
                    return "UPRIGHT"
        else:
            if state.Player.x - state.Monkey.prev_y  <= 2.31:
                return "DOWN"
            else:
                if state.FallingCoconut.x - state.ThrownCoconut.y  <= -0.30:
                    return "DOWN"
                else:
                    return "DOWNLEFTFIRE"
    else:
        return "LEFT"
