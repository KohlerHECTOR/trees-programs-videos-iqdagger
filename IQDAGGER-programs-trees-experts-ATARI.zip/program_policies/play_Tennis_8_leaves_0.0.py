def play(state):
    if state.Player.x - state.Player.prev_x  <= 0.09:
        if state.Player.x - state.BallShadow.prev_y  <= -1.08:
            if state.Player.y - state.Enemy.prev_x  <= -0.00:
                return "DOWNLEFT"
            else:
                return "DOWNRIGHT"
        else:
            if state.Player.prev_y - state.Ball.y  <= -0.60:
                return "UPRIGHT"
            else:
                if state.Enemy.x - state.BallShadow.y  <= 0.32:
                    return "UPLEFTFIRE"
                else:
                    return "DOWNLEFT"
    else:
        if state.Enemy.prev_y - state.Ball.prev_x  <= -0.73:
            return "DOWNRIGHT"
        else:
            if state.Player.prev_y - state.Ball.y  <= -0.63:
                return "UPRIGHT"
            else:
                return "UPRIGHT"
