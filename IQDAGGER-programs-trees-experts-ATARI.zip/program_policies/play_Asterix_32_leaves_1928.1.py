def play(state):
    if state.Consumable.prev_y - state.Enemy.prev_y  <= -1.08:
        if state.Consumable.prev_x - state.Reward.prev_x  <= -2.18:
            if state.Consumable.y - state.Reward.x  <= -3.35:
                if state.Consumable.prev_x - state.Reward.x  <= -4.34:
                    return "DOWN"
                else:
                    return "DOWNRIGHT"
            else:
                return "DOWNRIGHT"
        else:
            if state.Consumable.y - state.Enemy.prev_x  <= -0.92:
                if state.Consumable.prev_y - state.Enemy.x  <= 0.66:
                    return "DOWNRIGHT"
                else:
                    return "DOWNLEFT"
            else:
                if state.Consumable.prev_x - state.Reward.prev_y  <= -0.11:
                    return "UPLEFT"
                else:
                    if state.Consumable.prev_y - state.Enemy.prev_x  <= -0.91:
                        return "DOWNRIGHT"
                    else:
                        return "UPRIGHT"
    else:
        if state.Reward.prev_y - state.Enemy.prev_x  <= 1.17:
            if state.Consumable.prev_y - state.Enemy.prev_x  <= -0.91:
                if state.Consumable.y - state.Enemy.prev_x  <= -1.21:
                    return "DOWNLEFT"
                else:
                    return "DOWNLEFT"
            else:
                if state.Reward.x - state.Enemy.prev_x  <= 0.73:
                    if state.Consumable.prev_x - state.Reward.prev_x  <= -0.73:
                        if state.Reward.prev_x - state.Reward.y  <= 0.40:
                            if state.Reward.prev_y - state.Enemy.x  <= -1.10:
                                return "DOWNLEFT"
                            else:
                                return "UPLEFT"
                        else:
                            return "DOWNLEFT"
                    else:
                        if state.Consumable.x - state.Enemy.prev_y  <= -0.02:
                            return "UPLEFT"
                        else:
                            if state.Consumable.prev_x - state.Enemy.y  <= -2.30:
                                return "UPLEFT"
                            else:
                                if state.Consumable.x - state.Player.y  <= 0.26:
                                    return "UP"
                                else:
                                    if state.Reward.prev_y - state.Enemy.prev_x  <= 1.34:
                                        return "UPLEFT"
                                    else:
                                        return "UP"
                else:
                    if state.Enemy.x - state.Player.prev_x  <= -1.69:
                        if state.Consumable.x - state.Enemy.x  <= 1.81:
                            return "DOWNRIGHT"
                        else:
                            return "UP"
                    else:
                        if state.Enemy.prev_x - state.Player.x  <= -1.61:
                            return "DOWNLEFT"
                        else:
                            if state.Enemy.prev_y - state.Enemy.prev_y  <= -1.01:
                                return "UP"
                            else:
                                return "UPLEFT"
        else:
            if state.Reward.prev_y - state.Enemy.prev_y  <= 2.55:
                if state.Enemy.prev_x - state.Enemy.y  <= -1.72:
                    return "RIGHT"
                else:
                    if state.Consumable.y - state.Enemy.x  <= -0.76:
                        if state.Reward.prev_x - state.Enemy.x  <= -0.94:
                            return "DOWNRIGHT"
                        else:
                            return "DOWNLEFT"
                    else:
                        if state.Player.y - state.Player.x  <= 1.44:
                            if state.Enemy.prev_y - state.Player.y  <= 0.04:
                                return "UPLEFT"
                            else:
                                return "UPLEFT"
                        else:
                            return "UP"
            else:
                if state.Consumable.prev_x - state.Enemy.prev_x  <= -0.38:
                    if state.Reward.prev_y - state.Player.prev_y  <= -0.56:
                        return "RIGHT"
                    else:
                        return "UPRIGHT"
                else:
                    return "UPRIGHT"
