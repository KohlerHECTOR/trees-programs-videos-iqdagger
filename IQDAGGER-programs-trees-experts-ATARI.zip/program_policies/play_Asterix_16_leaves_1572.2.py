def play(state):
    if state.Consumable.y - state.Enemy.prev_y  <= -1.01:
        if state.Consumable.prev_y - state.Reward.prev_x  <= -2.35:
            if state.Reward.prev_x - state.Reward.prev_x  <= -4.04:
                return "DOWN"
            else:
                return "DOWNRIGHT"
        else:
            if state.Consumable.prev_y - state.Enemy.x  <= -0.92:
                if state.Consumable.x - state.Enemy.prev_y  <= 1.92:
                    return "DOWNRIGHT"
                else:
                    return "DOWNLEFT"
            else:
                return "UPRIGHT"
    else:
        if state.Consumable.prev_y - state.Reward.y  <= 0.36:
            if state.Consumable.prev_x - state.Reward.prev_x  <= 0.06:
                if state.Consumable.y - state.Enemy.prev_x  <= -0.93:
                    return "DOWNLEFT"
                else:
                    return "UPLEFT"
            else:
                if state.Consumable.y - state.Enemy.x  <= 1.08:
                    return "DOWNLEFT"
                else:
                    return "UP"
        else:
            if state.Consumable.prev_y - state.Enemy.x  <= -0.91:
                return "DOWNLEFT"
            else:
                if state.Reward.prev_y - state.Enemy.prev_x  <= 2.41:
                    if state.Enemy.prev_y - state.Enemy.y  <= -1.52:
                        if state.Consumable.y - state.Player.y  <= -2.20:
                            return "DOWNRIGHT"
                        else:
                            return "RIGHT"
                    else:
                        if state.Consumable.y - state.Enemy.y  <= -1.20:
                            return "UPLEFT"
                        else:
                            return "UP"
                else:
                    if state.Reward.prev_x - state.Enemy.prev_x  <= -2.03:
                        return "RIGHT"
                    else:
                        return "UPRIGHT"
