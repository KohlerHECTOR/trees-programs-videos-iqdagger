def play(state):
    if state.Enemy.prev_y - state.Consumable.y  <= -1.01:
        if state.Reward.prev_x - state.Consumable.prev_y  <= -2.35:
            if state.Reward.prev_x - state.Reward.prev_x  <= -4.04:
                return "DOWN"
            else:
                return "DOWNRIGHT"
        else:
            if state.Enemy.x - state.Consumable.prev_y  <= -0.92:
                if state.Enemy.prev_y - state.Consumable.x  <= 1.92:
                    return "DOWNRIGHT"
                else:
                    return "DOWNLEFT"
            else:
                return "UPRIGHT"
    else:
        if state.Reward.y - state.Consumable.prev_y  <= 0.36:
            if state.Reward.prev_x - state.Consumable.prev_x  <= 0.06:
                if state.Enemy.prev_x - state.Consumable.y  <= -0.93:
                    return "DOWNLEFT"
                else:
                    return "UPLEFT"
            else:
                if state.Enemy.x - state.Consumable.y  <= 1.08:
                    return "DOWNLEFT"
                else:
                    return "UP"
        else:
            if state.Enemy.x - state.Consumable.prev_y  <= -0.91:
                return "DOWNLEFT"
            else:
                if state.Enemy.prev_x - state.Reward.prev_y  <= 2.41:
                    if state.Enemy.y - state.Enemy.prev_y  <= -1.52:
                        if state.Player.y - state.Consumable.y  <= -2.20:
                            return "DOWNRIGHT"
                        else:
                            return "RIGHT"
                    else:
                        if state.Enemy.y - state.Consumable.y  <= -1.20:
                            return "UPLEFT"
                        else:
                            return "UP"
                else:
                    if state.Enemy.prev_x - state.Reward.prev_x  <= -2.03:
                        return "RIGHT"
                    else:
                        return "UPRIGHT"
