def play(state):
    if state.Enemy.prev_x - state.Consumable.prev_y  <= -0.92:
        if state.Enemy.y - state.Consumable.prev_y  <= -1.12:
            return "DOWNRIGHT"
        else:
            return "DOWNLEFT"
    else:
        if state.Reward.y - state.Reward.x  <= -0.19:
            if state.Enemy.prev_y - state.Consumable.prev_y  <= -0.99:
                return "DOWNRIGHT"
            else:
                if state.Reward.y - state.Reward.x  <= 0.05:
                    return "UPLEFT"
                else:
                    return "UP"
        else:
            if state.Enemy.prev_y - state.Consumable.prev_y  <= -1.12:
                return "UPRIGHT"
            else:
                if state.Enemy.prev_y - state.Consumable.x  <= 0.32:
                    return "UPLEFT"
                else:
                    return "UP"
