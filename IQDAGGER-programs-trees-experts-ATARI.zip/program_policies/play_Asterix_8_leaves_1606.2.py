def play(state):
    if state.Consumable.prev_y - state.Enemy.prev_x  <= -0.92:
        if state.Consumable.prev_y - state.Enemy.y  <= -1.12:
            return "DOWNRIGHT"
        else:
            return "DOWNLEFT"
    else:
        if state.Reward.x - state.Reward.y  <= -0.19:
            if state.Consumable.prev_y - state.Enemy.prev_y  <= -0.99:
                return "DOWNRIGHT"
            else:
                if state.Reward.x - state.Reward.y  <= 0.05:
                    return "UPLEFT"
                else:
                    return "UP"
        else:
            if state.Consumable.prev_y - state.Enemy.prev_y  <= -1.12:
                return "UPRIGHT"
            else:
                if state.Consumable.x - state.Enemy.prev_y  <= 0.32:
                    return "UPLEFT"
                else:
                    return "UP"
