def play(state):
    if state.Chicken.prev_y - state.Chicken.y  <= -0.00:
        if state.Car.prev_x - state.Car.prev_x  <= 1.90:
            return "UP"
        else:
            return "UP"
    else:
        if state.Car.x - state.Car.prev_x  <= 0.52:
            if state.Car.prev_x - state.Car.x  <= -0.49:
                if state.Car.prev_x - state.Car.prev_x  <= 0.30:
                    return "UP"
                else:
                    return "UP"
            else:
                if state.Car.prev_x <= -0.00:
                    if state.Car.x - state.Car.prev_x  <= 0.89:
                        if state.Car.prev_x - state.Car.x  <= 1.75:
                            if state.Car.x - state.Chicken.prev_y  <= -0.02:
                                if state.Car.x - state.Chicken.prev_y  <= -1.80:
                                    return "UP"
                                else:
                                    return "NOOP"
                            else:
                                return "UP"
                        else:
                            return "NOOP"
                    else:
                        return "UP"
                else:
                    if state.Car.prev_x - state.Car.prev_x  <= 1.27:
                        if state.Car.prev_x - state.Car.prev_x  <= 0.18:
                            if state.Car.x - state.Chicken.prev_y  <= 0.34:
                                return "NOOP"
                            else:
                                return "UP"
                        else:
                            return "DOWN"
                    else:
                        if state.Car.x - state.Car.prev_x  <= -0.29:
                            return "UP"
                        else:
                            return "DOWN"
        else:
            if state.Car.x - state.Car.x  <= 2.69:
                return "UP"
            else:
                return "DOWN"
