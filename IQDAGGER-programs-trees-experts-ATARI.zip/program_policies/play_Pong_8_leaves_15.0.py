def play(state):
    if state.Player.y - state.Ball.prev_x  <= -0.59:
        if state.Ball.x <= -0.61:
            return "RIGHT"
        else:
            if state.Player.y - state.Ball.prev_x  <= -0.81:
                return "LEFT"
            else:
                return "NOOP"
    else:
        if state.Ball.x <= 0.05:
            if state.Enemy.y <= 0.25:
                return "LEFT"
            else:
                return "RIGHT"
        else:
            if state.Player.y - state.Enemy.y  <= -0.20:
                return "NOOP"
            else:
                if state.Player.y - state.Ball.prev_x  <= -0.43:
                    return "NOOP"
                else:
                    return "RIGHT"
