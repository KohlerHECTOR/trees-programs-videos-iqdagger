def play(state):
    if state.Alien.x - state.Alien.x  <= 0.05:
        if state.Alien.prev_x - state.Alien.y  <= -0.31:
            return "NOOP"
        else:
            if state.Alien.x - state.Alien.prev_x  <= -0.26:
                if state.Alien.x - state.Player.prev_x  <= 0.11:
                    return "LEFTFIRE"
                else:
                    return "LEFTFIRE"
            else:
                return "FIRE"
    else:
        if state.Alien.prev_x - state.Alien.x  <= -1.69:
            return "LEFTFIRE"
        else:
            if state.Alien.prev_x - state.Alien.prev_x  <= -0.35:
                return "RIGHTFIRE"
            else:
                if state.Alien.x - state.Alien.y  <= 0.79:
                    return "RIGHTFIRE"
                else:
                    return "RIGHTFIRE"
