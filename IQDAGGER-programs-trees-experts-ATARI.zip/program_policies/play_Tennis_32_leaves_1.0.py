def play(state):
    if state.Ball.y - state.BallShadow.prev_y  <= -1.04:
        if state.Player.x - state.BallShadow.y  <= 0.57:
            if state.Player.x - state.Player.prev_y  <= -1.94:
                if state.Enemy.x - state.Ball.prev_x  <= 1.01:
                    return "UPRIGHT"
                else:
                    return "UPRIGHT"
            else:
                return "UPRIGHT"
        else:
            if state.Player.prev_x - state.Enemy.x  <= -0.76:
                return "UPRIGHT"
            else:
                if state.Player.prev_x - state.Ball.x  <= -0.12:
                    if state.Ball.prev_x <= 0.64:
                        return "UP"
                    else:
                        return "UPRIGHT"
                else:
                    return "UPLEFTFIRE"
    else:
        if state.Player.x - state.BallShadow.prev_y  <= -1.15:
            if state.Player.x - state.Ball.y  <= -0.43:
                if state.Ball.y - state.BallShadow.prev_y  <= 0.24:
                    if state.Enemy.x - state.Enemy.prev_y  <= -1.58:
                        return "DOWNLEFT"
                    else:
                        return "UPRIGHT"
                else:
                    if state.Ball.x - state.BallShadow.y  <= 1.29:
                        return "DOWNRIGHT"
                    else:
                        return "DOWNLEFT"
            else:
                if state.BallShadow.prev_x <= 0.36:
                    return "DOWNLEFT"
                else:
                    if state.Player.prev_y - state.Ball.y  <= -0.29:
                        return "DOWNRIGHT"
                    else:
                        return "DOWNLEFT"
        else:
            if state.Player.prev_y - state.Ball.y  <= -0.59:
                if state.Ball.prev_x <= -0.08:
                    return "UPLEFTFIRE"
                else:
                    if state.Player.prev_x - state.Enemy.x  <= -0.95:
                        if state.Ball.y - state.BallShadow.prev_y  <= 0.17:
                            return "UPRIGHT"
                        else:
                            return "UPRIGHT"
                    else:
                        if state.Enemy.prev_y - state.BallShadow.prev_x  <= -0.17:
                            return "RIGHTFIRE"
                        else:
                            if state.Player.y - state.Enemy.x  <= -0.76:
                                return "RIGHTFIRE"
                            else:
                                return "UPRIGHT"
            else:
                if state.Player.x - state.Player.prev_x  <= -0.00:
                    if state.Enemy.x - state.BallShadow.y  <= 0.01:
                        if state.Player.prev_x - state.Enemy.x  <= -0.01:
                            return "UPLEFTFIRE"
                        else:
                            if state.Enemy.prev_y - state.BallShadow.prev_x  <= -0.33:
                                return "DOWNLEFT"
                            else:
                                return "UPLEFTFIRE"
                    else:
                        return "DOWNLEFT"
                else:
                    if state.Player.prev_y - state.BallShadow.y  <= -0.22:
                        if state.Ball.prev_x <= 0.27:
                            return "DOWNLEFT"
                        else:
                            if state.Player.prev_y - state.Ball.y  <= 0.52:
                                if state.Player.prev_y <= -0.84:
                                    return "DOWNRIGHT"
                                else:
                                    return "UPRIGHT"
                            else:
                                return "DOWNLEFT"
                    else:
                        if state.Ball.y - state.BallShadow.x  <= -2.30:
                            return "DOWNRIGHT"
                        else:
                            if state.Ball.y <= -0.69:
                                return "UP"
                            else:
                                if state.Ball.x <= 0.15:
                                    return "DOWNLEFT"
                                else:
                                    return "UPLEFTFIRE"
