def play(state):
    if state.Submarine.x - state.Player.prev_y  <= 0.47:
        if state.Diver.x - state.Diver.x  <= -0.57:
            if state.EnemyMissile.y - state.Player.prev_x  <= -0.87:
                return "DOWNRIGHTFIRE"
            else:
                return "DOWNFIRE"
        else:
            if state.Shark.prev_x - state.Diver.x  <= 0.92:
                if state.EnemyMissile.y - state.Player.prev_x  <= -0.39:
                    return "UPRIGHTFIRE"
                else:
                    return "UPFIRE"
            else:
                return "DOWNRIGHTFIRE"
    else:
        if state.Diver.x - state.Diver.x  <= 0.88:
            return "DOWNLEFT"
        else:
            if state.Submarine.x - state.Shark.prev_x  <= 0.21:
                return "UPLEFTFIRE"
            else:
                return "DOWNLEFTFIRE"
