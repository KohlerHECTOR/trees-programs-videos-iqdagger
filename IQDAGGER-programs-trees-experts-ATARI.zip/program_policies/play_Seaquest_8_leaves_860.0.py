def play(state):
    if state.Player.prev_y - state.Submarine.x  <= 0.47:
        if state.Diver.x - state.Diver.x  <= -0.57:
            if state.Player.prev_x - state.EnemyMissile.y  <= -0.87:
                return "DOWNRIGHTFIRE"
            else:
                return "DOWNFIRE"
        else:
            if state.Diver.x - state.Shark.prev_x  <= 0.92:
                if state.Player.prev_x - state.EnemyMissile.y  <= -0.39:
                    return "UPRIGHTFIRE"
                else:
                    return "UPFIRE"
            else:
                return "DOWNRIGHTFIRE"
    else:
        if state.Diver.x - state.Diver.x  <= 0.88:
            return "DOWNLEFT"
        else:
            if state.Shark.prev_x - state.Submarine.x  <= 0.21:
                return "UPLEFTFIRE"
            else:
                return "DOWNLEFTFIRE"
