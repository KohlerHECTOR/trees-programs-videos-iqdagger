def play(state):
    if state.Player.prev_y - state.Submarine.prev_x  <= 0.51:
        if state.Diver.x - state.Diver.x  <= -0.56:
            if state.Diver.prev_x - state.EnemyMissile.prev_x  <= 1.24:
                return "DOWNFIRE"
            else:
                if state.Player.prev_x - state.EnemyMissile.prev_y  <= -0.71:
                    return "DOWNRIGHTFIRE"
                else:
                    return "DOWNFIRE"
        else:
            if state.Diver.prev_y - state.Shark.prev_x  <= 0.92:
                if state.Player.prev_x - state.EnemyMissile.prev_y  <= -0.58:
                    if state.Shark.prev_x - state.Submarine.x  <= 0.02:
                        return "UPRIGHTFIRE"
                    else:
                        return "UPRIGHTFIRE"
                else:
                    if state.Shark.x - state.Shark.y  <= -3.89:
                        return "UPRIGHTFIRE"
                    else:
                        if state.Shark.y <= 0.93:
                            return "UPFIRE"
                        else:
                            return "DOWNFIRE"
            else:
                return "DOWNRIGHTFIRE"
    else:
        if state.Shark.y <= 0.53:
            if state.Diver.prev_x - state.Shark.prev_x  <= 0.13:
                return "UPLEFTFIRE"
            else:
                if state.Diver.x - state.Shark.x  <= 1.87:
                    if state.Shark.y - state.EnemyMissile.y  <= -0.31:
                        return "DOWNFIRE"
                    else:
                        return "DOWNLEFT"
                else:
                    return "DOWNLEFT"
        else:
            if state.Shark.prev_x - state.Submarine.x  <= 0.18:
                if state.Player.prev_x - state.EnemyMissile.prev_y  <= 1.22:
                    return "UPFIRE"
                else:
                    return "UPLEFTFIRE"
            else:
                return "DOWNLEFTFIRE"
