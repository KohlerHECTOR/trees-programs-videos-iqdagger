def play(state):
    if state.Submarine.prev_x - state.Player.prev_y  <= 0.51:
        if state.Diver.x - state.Diver.x  <= -0.56:
            if state.EnemyMissile.prev_x - state.Diver.prev_x  <= 1.24:
                return "DOWNFIRE"
            else:
                if state.EnemyMissile.prev_y - state.Player.prev_x  <= -0.71:
                    return "DOWNRIGHTFIRE"
                else:
                    return "DOWNFIRE"
        else:
            if state.Shark.prev_x - state.Diver.prev_y  <= 0.92:
                if state.EnemyMissile.prev_y - state.Player.prev_x  <= -0.58:
                    if state.Submarine.x - state.Shark.prev_x  <= 0.02:
                        return "UPRIGHTFIRE"
                    else:
                        return "UPRIGHTFIRE"
                else:
                    if state.Shark.y - state.Shark.x  <= -3.89:
                        return "UPRIGHTFIRE"
                    else:
                        if state.Shark.y <= 0.93:
                            return "UPFIRE"
                        else:
                            return "DOWNFIRE"
            else:
                return "DOWNRIGHTFIRE"
    else:
        if state.Shark.y <= 0.53:
            if state.Shark.prev_x - state.Diver.prev_x  <= 0.13:
                return "UPLEFTFIRE"
            else:
                if state.Shark.x - state.Diver.x  <= 1.87:
                    if state.EnemyMissile.y - state.Shark.y  <= -0.31:
                        return "DOWNFIRE"
                    else:
                        return "DOWNLEFT"
                else:
                    return "DOWNLEFT"
        else:
            if state.Submarine.x - state.Shark.prev_x  <= 0.18:
                if state.EnemyMissile.prev_y - state.Player.prev_x  <= 1.22:
                    return "UPFIRE"
                else:
                    return "UPLEFTFIRE"
            else:
                return "DOWNLEFTFIRE"
