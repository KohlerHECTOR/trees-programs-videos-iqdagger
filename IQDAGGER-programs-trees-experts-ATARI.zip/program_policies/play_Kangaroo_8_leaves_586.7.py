def play(state):
    if state.Player.x - state.Monkey.x  <= 3.17:
        if state.Monkey.x - state.FallingCoconut.prev_x  <= 1.74:
            if state.Monkey.prev_y - state.Monkey.y  <= -1.02:
                if state.Player.x - state.FallingCoconut.x  <= -0.45:
                    return "DOWNRIGHTFIRE"
                else:
                    return "LEFT"
            else:
                if state.Monkey.y - state.FallingCoconut.prev_y  <= 0.29:
                    return "DOWNLEFTFIRE"
                else:
                    if state.Player.x - state.FallingCoconut.x  <= -1.27:
                        return "RIGHT"
                    else:
                        return "DOWN"
        else:
            return "UPRIGHT"
    else:
        if state.Monkey.x - state.ThrownCoconut.y  <= -0.04:
            return "DOWN"
        else:
            return "DOWN"
