def play(state):
    if state.Monkey.x - state.Player.x  <= 3.17:
        if state.FallingCoconut.prev_x - state.Monkey.x  <= 1.74:
            if state.Monkey.y - state.Monkey.prev_y  <= -1.02:
                if state.FallingCoconut.x - state.Player.x  <= -0.45:
                    return "DOWNRIGHTFIRE"
                else:
                    return "LEFT"
            else:
                if state.FallingCoconut.prev_y - state.Monkey.y  <= 0.29:
                    return "DOWNLEFTFIRE"
                else:
                    if state.FallingCoconut.x - state.Player.x  <= -1.27:
                        return "RIGHT"
                    else:
                        return "DOWN"
        else:
            return "UPRIGHT"
    else:
        if state.ThrownCoconut.y - state.Monkey.x  <= -0.04:
            return "DOWN"
        else:
            return "DOWN"
