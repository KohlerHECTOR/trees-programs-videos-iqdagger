def play(state):
    if state.Chicken.y - state.Chicken.prev_y  <= -0.00:
        return "UP"
    else:
        if state.Car.prev_x - state.Car.x  <= 0.63:
            if state.Car.x - state.Car.x  <= 1.13:
                if state.Car.prev_x <= -0.19:
                    return "UP"
                else:
                    if state.Car.prev_x - state.Car.prev_x  <= -0.92:
                        if state.Car.prev_x - state.Car.prev_x  <= 0.17:
                            return "NOOP"
                        else:
                            return "UP"
                    else:
                        return "UP"
            else:
                if state.Car.prev_x - state.Car.prev_x  <= 1.12:
                    return "DOWN"
                else:
                    return "UP"
        else:
            return "UP"
