def play(state):
    if state.Player.x - state.Monkey.x  <= 3.17:
        if state.Monkey.prev_x - state.Monkey.prev_x  <= 1.86:
            if state.FallingCoconut.y <= 1.05:
                if state.Monkey.x - state.ThrownCoconut.prev_x  <= 1.33:
                    if state.Monkey.prev_y - state.ThrownCoconut.prev_x  <= 1.03:
                        if state.Monkey.y - state.FallingCoconut.y  <= -1.03:
                            if state.Monkey.x - state.ThrownCoconut.y  <= -0.45:
                                return "DOWNLEFTFIRE"
                            else:
                                if state.Monkey.prev_x - state.FallingCoconut.x  <= -1.20:
                                    return "DOWNLEFT"
                                else:
                                    return "LEFT"
                        else:
                            if state.Monkey.prev_x - state.FallingCoconut.y  <= 0.07:
                                return "NOOP"
                            else:
                                return "UPFIRE"
                    else:
                        if state.Monkey.x - state.FallingCoconut.prev_x  <= 0.97:
                            if state.Player.x - state.Monkey.prev_x  <= 2.38:
                                return "UPLEFTFIRE"
                            else:
                                return "DOWNLEFTFIRE"
                        else:
                            return "UPLEFT"
                else:
                    if state.Player.x - state.FallingCoconut.y  <= 0.44:
                        return "LEFT"
                    else:
                        return "LEFT"
            else:
                if state.Player.x - state.FallingCoconut.x  <= -0.67:
                    if state.Monkey.prev_y - state.FallingCoconut.prev_x  <= -0.99:
                        if state.Player.y - state.Player.prev_x  <= -0.07:
                            if state.Monkey.prev_x - state.Monkey.prev_x  <= -0.95:
                                return "RIGHT"
                            else:
                                if state.Player.y - state.Monkey.prev_y  <= -1.10:
                                    return "DOWNLEFT"
                                else:
                                    return "DOWN"
                        else:
                            if state.Monkey.x - state.Monkey.y  <= 0.10:
                                return "DOWNRIGHT"
                            else:
                                return "DOWNLEFTFIRE"
                    else:
                        if state.Player.y - state.Monkey.prev_y  <= -1.28:
                            return "RIGHT"
                        else:
                            if state.Monkey.x - state.Monkey.prev_x  <= 2.00:
                                if state.Monkey.prev_x - state.FallingCoconut.y  <= -0.01:
                                    return "DOWN"
                                else:
                                    return "DOWN"
                            else:
                                return "DOWNRIGHT"
                else:
                    if state.Player.x - state.Monkey.x  <= 0.23:
                        if state.Child.x - state.FallingCoconut.y  <= -0.06:
                            if state.FallingCoconut.x - state.Life.prev_x  <= 1.96:
                                return "LEFT"
                            else:
                                return "DOWNLEFT"
                        else:
                            return "LEFT"
                    else:
                        if state.Player.y - state.Monkey.x  <= -0.01:
                            return "DOWNLEFTFIRE"
                        else:
                            if state.Monkey.prev_y - state.FallingCoconut.prev_x  <= -2.93:
                                return "DOWNRIGHTFIRE"
                            else:
                                return "DOWNRIGHTFIRE"
        else:
            if state.Player.x - state.Monkey.x  <= -0.50:
                return "UPRIGHT"
            else:
                return "UPRIGHT"
    else:
        if state.Player.x - state.Monkey.x  <= 0.99:
            if state.Monkey.x - state.FallingCoconut.y  <= 0.57:
                return "DOWN"
            else:
                if state.Monkey.x - state.Monkey.prev_x  <= -0.31:
                    return "DOWN"
                else:
                    return "DOWN"
        else:
            if state.Monkey.y - state.ThrownCoconut.x  <= -9.81:
                return "DOWNLEFTFIRE"
            else:
                return "DOWN"
