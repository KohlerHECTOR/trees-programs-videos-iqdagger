def play(state):
    if state.Monkey.x - state.Player.x  <= 3.17:
        if state.Monkey.prev_x - state.Monkey.prev_x  <= 1.86:
            if state.FallingCoconut.y <= 1.05:
                if state.ThrownCoconut.prev_x - state.Monkey.x  <= 1.33:
                    if state.ThrownCoconut.prev_x - state.Monkey.prev_y  <= 1.03:
                        if state.FallingCoconut.y - state.Monkey.y  <= -1.03:
                            if state.ThrownCoconut.y - state.Monkey.x  <= -0.45:
                                return "DOWNLEFTFIRE"
                            else:
                                if state.FallingCoconut.x - state.Monkey.prev_x  <= -1.20:
                                    return "DOWNLEFT"
                                else:
                                    return "LEFT"
                        else:
                            if state.FallingCoconut.y - state.Monkey.prev_x  <= 0.07:
                                return "NOOP"
                            else:
                                return "UPFIRE"
                    else:
                        if state.FallingCoconut.prev_x - state.Monkey.x  <= 0.97:
                            if state.Monkey.prev_x - state.Player.x  <= 2.38:
                                return "UPLEFTFIRE"
                            else:
                                return "DOWNLEFTFIRE"
                        else:
                            return "UPLEFT"
                else:
                    if state.FallingCoconut.y - state.Player.x  <= 0.44:
                        return "LEFT"
                    else:
                        return "LEFT"
            else:
                if state.FallingCoconut.x - state.Player.x  <= -0.67:
                    if state.FallingCoconut.prev_x - state.Monkey.prev_y  <= -0.99:
                        if state.Player.prev_x - state.Player.y  <= -0.07:
                            if state.Monkey.prev_x - state.Monkey.prev_x  <= -0.95:
                                return "RIGHT"
                            else:
                                if state.Monkey.prev_y - state.Player.y  <= -1.10:
                                    return "DOWNLEFT"
                                else:
                                    return "DOWN"
                        else:
                            if state.Monkey.y - state.Monkey.x  <= 0.10:
                                return "DOWNRIGHT"
                            else:
                                return "DOWNLEFTFIRE"
                    else:
                        if state.Monkey.prev_y - state.Player.y  <= -1.28:
                            return "RIGHT"
                        else:
                            if state.Monkey.prev_x - state.Monkey.x  <= 2.00:
                                if state.FallingCoconut.y - state.Monkey.prev_x  <= -0.01:
                                    return "DOWN"
                                else:
                                    return "DOWN"
                            else:
                                return "DOWNRIGHT"
                else:
                    if state.Monkey.x - state.Player.x  <= 0.23:
                        if state.FallingCoconut.y - state.Child.x  <= -0.06:
                            if state.Life.prev_x - state.FallingCoconut.x  <= 1.96:
                                return "LEFT"
                            else:
                                return "DOWNLEFT"
                        else:
                            return "LEFT"
                    else:
                        if state.Monkey.x - state.Player.y  <= -0.01:
                            return "DOWNLEFTFIRE"
                        else:
                            if state.FallingCoconut.prev_x - state.Monkey.prev_y  <= -2.93:
                                return "DOWNRIGHTFIRE"
                            else:
                                return "DOWNRIGHTFIRE"
        else:
            if state.Monkey.x - state.Player.x  <= -0.50:
                return "UPRIGHT"
            else:
                return "UPRIGHT"
    else:
        if state.Monkey.x - state.Player.x  <= 0.99:
            if state.FallingCoconut.y - state.Monkey.x  <= 0.57:
                return "DOWN"
            else:
                if state.Monkey.prev_x - state.Monkey.x  <= -0.31:
                    return "DOWN"
                else:
                    return "DOWN"
        else:
            if state.ThrownCoconut.x - state.Monkey.y  <= -9.81:
                return "DOWNLEFTFIRE"
            else:
                return "DOWN"
