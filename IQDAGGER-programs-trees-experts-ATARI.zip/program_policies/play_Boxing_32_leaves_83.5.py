def play(state):
    if state.Player.prev_x - state.Player.x  <= -0.06:
        if state.Enemy.x - state.Player.x  <= 0.03:
            if state.Enemy.x - state.Player.y  <= -0.41:
                if state.Player.prev_y <= 0.89:
                    return "DOWNLEFT"
                else:
                    return "UPLEFT"
            else:
                if state.Player.prev_x <= -0.10:
                    if state.Enemy.prev_x - state.Player.y  <= 0.83:
                        if state.Enemy.prev_x - state.Player.y  <= -0.18:
                            return "RIGHT"
                        else:
                            return "UPRIGHT"
                    else:
                        return "UPLEFT"
                else:
                    if state.Enemy.prev_y - state.Player.prev_x  <= 0.82:
                        return "UPLEFT"
                    else:
                        return "DOWNLEFT"
        else:
            if state.Enemy.prev_y - state.Enemy.x  <= 0.84:
                if state.Player.y <= 0.63:
                    if state.Enemy.prev_y - state.Enemy.x  <= -0.58:
                        return "DOWNLEFT"
                    else:
                        return "DOWNLEFT"
                else:
                    return "DOWNLEFT"
            else:
                return "UPLEFT"
    else:
        if state.Player.prev_x <= 0.10:
            if state.Enemy.prev_x - state.Player.y  <= -0.15:
                if state.Player.x <= -0.50:
                    if state.Enemy.prev_x - state.Player.y  <= -0.90:
                        return "DOWNRIGHT"
                    else:
                        return "RIGHT"
                else:
                    if state.Enemy.prev_y - state.Enemy.y  <= 0.00:
                        if state.Enemy.prev_y - state.Enemy.y  <= -0.18:
                            return "DOWNRIGHTFIRE"
                        else:
                            return "UPRIGHTFIRE"
                    else:
                        return "UPRIGHTFIRE"
            else:
                if state.Enemy.prev_x - state.Player.y  <= 0.76:
                    if state.Player.prev_y - state.Player.prev_x  <= 0.27:
                        if state.Player.prev_x <= -0.39:
                            return "RIGHT"
                        else:
                            return "DOWNRIGHTFIRE"
                    else:
                        return "UPRIGHT"
                else:
                    return "UP"
        else:
            if state.Enemy.y - state.Enemy.x  <= 0.10:
                if state.Enemy.prev_y - state.Enemy.y  <= -0.09:
                    if state.Enemy.prev_x - state.Player.y  <= -0.69:
                        if state.Enemy.y - state.Player.prev_x  <= 1.31:
                            return "DOWNRIGHT"
                        else:
                            return "DOWNRIGHTFIRE"
                    else:
                        return "DOWNRIGHTFIRE"
                else:
                    if state.Enemy.y - state.Player.x  <= -0.04:
                        if state.Player.prev_y - state.Player.prev_x  <= -0.69:
                            if state.Enemy.prev_y - state.Player.x  <= 1.31:
                                return "DOWNRIGHT"
                            else:
                                return "UPRIGHTFIRE"
                        else:
                            return "UPRIGHTFIRE"
                    else:
                        if state.Enemy.prev_x - state.Player.y  <= -0.63:
                            return "DOWNRIGHT"
                        else:
                            return "DOWNRIGHTFIRE"
            else:
                if state.Enemy.prev_y - state.Player.prev_x  <= 1.19:
                    if state.Enemy.prev_y - state.Enemy.x  <= 0.26:
                        if state.Enemy.prev_y - state.Enemy.y  <= -0.18:
                            return "DOWNRIGHTFIRE"
                        else:
                            return "DOWNLEFT"
                    else:
                        return "DOWNLEFT"
                else:
                    return "DOWNLEFT"
