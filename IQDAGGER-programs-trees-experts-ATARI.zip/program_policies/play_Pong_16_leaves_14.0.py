def play(state):
    if state.Player.y - state.Ball.prev_x  <= -0.72:
        if state.Ball.x <= -0.80:
            return "RIGHT"
        else:
            if state.Player.y - state.Ball.prev_x  <= -0.87:
                if state.Ball.prev_x <= -0.16:
                    return "LEFT"
                else:
                    return "LEFT"
            else:
                if state.Ball.x <= 1.08:
                    return "LEFT"
                else:
                    return "NOOP"
    else:
        if state.Ball.prev_x <= 0.84:
            if state.Enemy.prev_y <= -0.62:
                if state.Player.prev_y - state.Ball.y  <= 0.09:
                    return "LEFT"
                else:
                    return "RIGHT"
            else:
                if state.Ball.prev_y - state.Enemy.y  <= -1.69:
                    return "RIGHT"
                else:
                    if state.Ball.y <= 1.29:
                        if state.Player.y - state.Ball.prev_x  <= -0.53:
                            return "NOOP"
                        else:
                            if state.Ball.x - state.Enemy.prev_y  <= 0.22:
                                return "NOOP"
                            else:
                                return "RIGHT"
                    else:
                        return "NOOP"
        else:
            if state.Player.y - state.Ball.prev_x  <= -0.52:
                if state.Player.y - state.Ball.y  <= -2.82:
                    return "RIGHT"
                else:
                    return "NOOP"
            else:
                if state.Player.y - state.Enemy.y  <= -0.18:
                    return "NOOP"
                else:
                    return "RIGHT"
