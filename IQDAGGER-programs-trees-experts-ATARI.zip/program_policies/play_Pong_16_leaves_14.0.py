def play(state):
    if state.Ball.prev_x - state.Player.y  <= -0.72:
        if state.Ball.x <= -0.80:
            return "RIGHT"
        else:
            if state.Ball.prev_x - state.Player.y  <= -0.87:
                if state.Ball.prev_x <= -0.16:
                    return "LEFT"
                else:
                    return "LEFT"
            else:
                if state.Ball.x <= 1.08:
                    return "LEFT"
                else:
                    return "NOOP"
    else:
        if state.Ball.prev_x <= 0.84:
            if state.Enemy.prev_y <= -0.62:
                if state.Ball.y - state.Player.prev_y  <= 0.09:
                    return "LEFT"
                else:
                    return "RIGHT"
            else:
                if state.Enemy.y - state.Ball.prev_y  <= -1.69:
                    return "RIGHT"
                else:
                    if state.Ball.y <= 1.29:
                        if state.Ball.prev_x - state.Player.y  <= -0.53:
                            return "NOOP"
                        else:
                            if state.Enemy.prev_y - state.Ball.x  <= 0.22:
                                return "NOOP"
                            else:
                                return "RIGHT"
                    else:
                        return "NOOP"
        else:
            if state.Ball.prev_x - state.Player.y  <= -0.52:
                if state.Ball.y - state.Player.y  <= -2.82:
                    return "RIGHT"
                else:
                    return "NOOP"
            else:
                if state.Enemy.y - state.Player.y  <= -0.18:
                    return "NOOP"
                else:
                    return "RIGHT"
