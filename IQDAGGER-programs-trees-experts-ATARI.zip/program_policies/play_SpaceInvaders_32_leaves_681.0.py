def play(state):
    if state.Player.prev_x - state.Alien.x  <= -0.96:
        if state.Alien.prev_x - state.Alien.x  <= 0.18:
            if state.Alien.prev_x - state.Bullet.y  <= -1.45:
                if state.Player.x - state.Alien.prev_y  <= -1.25:
                    return "RIGHTFIRE"
                else:
                    return "LEFTFIRE"
            else:
                if state.Alien.x - state.Alien.prev_x  <= -0.76:
                    return "NOOP"
                else:
                    return "LEFT"
        else:
            if state.Player.prev_x - state.Alien.prev_y  <= 2.04:
                return "LEFTFIRE"
            else:
                return "LEFTFIRE"
    else:
        if state.Alien.prev_y - state.Alien.prev_x  <= 0.15:
            if state.Alien.prev_x - state.Alien.x  <= 0.29:
                if state.Alien.prev_y - state.Alien.y  <= 0.51:
                    if state.Alien.prev_y - state.Alien.prev_x  <= 0.69:
                        if state.Alien.y - state.Bullet.prev_y  <= -0.51:
                            if state.Alien.y - state.Bullet.x  <= -1.18:
                                return "NOOP"
                            else:
                                return "NOOP"
                        else:
                            return "NOOP"
                    else:
                        if state.Alien.prev_x - state.Alien.y  <= -0.34:
                            return "LEFT"
                        else:
                            return "NOOP"
                else:
                    if state.Alien.y - state.Bullet.x  <= 0.17:
                        return "RIGHT"
                    else:
                        return "NOOP"
            else:
                if state.Alien.prev_y - state.Satellite.prev_x  <= 1.23:
                    if state.Alien.x - state.Alien.y  <= 2.14:
                        if state.Alien.x - state.Alien.prev_x  <= -0.19:
                            return "LEFTFIRE"
                        else:
                            if state.Player.prev_x - state.Alien.prev_x  <= -0.05:
                                if state.Alien.x - state.Bullet.prev_x  <= 0.99:
                                    return "LEFTFIRE"
                                else:
                                    return "LEFTFIRE"
                            else:
                                return "RIGHTFIRE"
                    else:
                        return "RIGHTFIRE"
                else:
                    if state.Alien.x - state.Bullet.x  <= -0.51:
                        return "RIGHTFIRE"
                    else:
                        if state.Alien.prev_y - state.Alien.prev_x  <= -2.08:
                            return "LEFTFIRE"
                        else:
                            return "FIRE"
        else:
            if state.Alien.x - state.Alien.prev_y  <= -0.36:
                if state.Alien.prev_x - state.Alien.x  <= -0.16:
                    if state.Alien.prev_x - state.Alien.x  <= -0.04:
                        if state.Alien.x - state.Alien.prev_x  <= 1.24:
                            if state.Alien.prev_y - state.Alien.x  <= -0.82:
                                return "RIGHTFIRE"
                            else:
                                return "RIGHT"
                        else:
                            return "LEFTFIRE"
                    else:
                        return "NOOP"
                else:
                    if state.Alien.x - state.Alien.prev_y  <= 0.81:
                        return "RIGHTFIRE"
                    else:
                        return "RIGHTFIRE"
            else:
                if state.Alien.y - state.Alien.y  <= -0.56:
                    if state.Alien.prev_y - state.Alien.y  <= 1.50:
                        if state.Alien.prev_y - state.Bullet.y  <= 0.04:
                            return "RIGHT"
                        else:
                            if state.Alien.prev_x - state.Alien.y  <= 2.03:
                                return "FIRE"
                            else:
                                return "RIGHT"
                    else:
                        return "RIGHTFIRE"
                else:
                    return "RIGHTFIRE"
